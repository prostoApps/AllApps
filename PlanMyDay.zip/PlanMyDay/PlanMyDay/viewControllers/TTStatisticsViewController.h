//
//  TTStatisticsViewController.h
//  TimeTracker
//
//  Created by Yegor Karpechenkov on 6/29/13.
//  Copyright (c) 2013 prosto*. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TTStatisticsViewController : UIViewController

@end
