//
//  TTCurrentTaskNextTaskIndicatorViewController.h
//  PlanMyDay
//
//  Created by Yegor Karpechenkov on 8/1/13.
//  Copyright (c) 2013 prosto*. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TTCurrentTaskNextTaskIndicatorViewController : UIViewController

@end
