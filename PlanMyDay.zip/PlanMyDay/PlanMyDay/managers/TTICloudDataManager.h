//
//  TTICloudDataManager.h
//  TimeTracker
//
//  Created by Yegor Karpechenkov on 5/25/13.
//  Copyright (c) 2013 prosto*. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface TTICloudDataManager : NSObject

@end
