#import "Section.h"


@implementation Section

@synthesize sectionHeader, sectionRows,open,sectionHeaderView;


@end
